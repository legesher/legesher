"""OpenAI-compatible translation provider for local and cloud models.

Targets the standard /v1/chat/completions API format, working with:
- vLLM (vllm serve model-name)
- Ollama (ollama run model-name)
- llama.cpp server
- LocalAI
- Any OpenAI-compatible API (OpenAI, Azure OpenAI, etc.)

Users serve any model and point this provider at the endpoint.
"""

import logging
import os
from datetime import datetime

import httpx

from legesher_i18n.prompt_builder import PLAIN_TEXT_SYSTEM_PROMPT

from .base import (
    TranslationError,
    TranslationProvider,
    TranslationResult,
    UsageStats,
)

logger = logging.getLogger(__name__)

# CORE-1804: the fallback prompt lives in ONE place now
# (legesher_i18n.prompt_builder.PLAIN_TEXT_SYSTEM_PROMPT); the provider-local
# copy is deleted. Kept as a module alias for existing imports.
_SYSTEM_PROMPT = PLAIN_TEXT_SYSTEM_PROMPT


class OpenAICompatProvider(TranslationProvider):
    """OpenAI-compatible translation provider.

    Connects to any endpoint serving the OpenAI chat completions API.
    Designed for plug-and-play use with local models (Tiny Aya via vLLM,
    Ollama, etc.) or any OpenAI-compatible cloud API.

    Example:
        >>> # Local model via vLLM
        >>> provider = OpenAICompatProvider(
        ...     base_url="http://localhost:8000",
        ...     model="CohereForAI/aya-expanse-8b",
        ... )
        >>> result = await provider.translate("Hello", "en", "es")

        >>> # Ollama
        >>> provider = OpenAICompatProvider(
        ...     base_url="http://localhost:11434/v1",
        ...     model="aya",
        ... )
    """

    name = "openai_compat"
    requires_api_key = False

    def __init__(
        self,
        base_url: str | None = None,
        model: str = "default",
        api_key: str | None = None,
        timeout: float = 120.0,
    ) -> None:
        self._base_url = (
            base_url or os.getenv("OPENAI_BASE_URL", "http://localhost:8000")
        ).rstrip("/")
        self._model = model
        self._api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        self._timeout = timeout
        self._total_requests = 0
        self._total_tokens_in = 0
        self._total_tokens_out = 0

        # Initialize PromptBuilder — the sole prompt source (CORE-1804).
        # Failure is loud: style guides are load-bearing (CORE-1354).
        self._prompt_builder = None
        try:
            from legesher_i18n.style_guides import StyleGuideLoader
            from legesher_i18n.prompt_builder import PromptBuilder

            loader = StyleGuideLoader()
            self._prompt_builder = PromptBuilder(loader)
        except Exception as exc:
            logger.warning(
                "PromptBuilder failed to initialize — falling back to the "
                "minimal plain-text prompt; style guides will NOT be applied "
                "and results are flagged prompt_source='legacy_fallback': %s",
                exc,
            )

    def is_available(self) -> bool:
        # Can't easily check without making a request — assume available
        return True

    def supports(self, source_lang: str, target_lang: str) -> bool:
        # Depends on the model — assume yes
        return True

    async def translate(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        context: dict | None = None,
    ) -> TranslationResult:
        # Use PromptBuilder when available and context is provided
        prompt_source = "prompt_builder"
        if self._prompt_builder and context:
            glossary = context.get("glossary", {})
            kind = context.get("kind")

            if kind:  # text element (comment/docstring/string)
                system_prompt, user_prompt = self._prompt_builder.build_text_prompt(
                    texts=[{"text": text, "kind": kind, "context": context}],
                    target_lang=target_lang,
                    identifier_glossary=glossary,
                )
            else:  # identifier
                system_prompt, user_prompt = (
                    self._prompt_builder.build_identifier_prompt(
                        identifiers=[
                            {
                                "text": text,
                                "role": context.get("role", "unknown"),
                                "context": context,
                            }
                        ],
                        target_lang=target_lang,
                        existing_glossary=glossary,
                        forbidden_values=context.get("forbidden_values"),
                    )
                )
        else:
            if context:
                # Context was provided but PromptBuilder is broken — this is
                # a style-guide regression; make it loud and flag it.
                prompt_source = "legacy_fallback"
                logger.warning(
                    "PromptBuilder unavailable — translating '%s' (%s->%s) "
                    "with the minimal fallback prompt; style guides NOT "
                    "applied",
                    text[:50],
                    source_lang,
                    target_lang,
                )
            else:
                prompt_source = "plain_text"
            system_prompt = PLAIN_TEXT_SYSTEM_PROMPT.format(
                source_lang=source_lang, target_lang=target_lang
            )
            user_prompt = text

        payload = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.1,
            "max_tokens": 4096,
        }

        headers = {"Content-Type": "application/json"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        # Handle base_url with or without /v1 suffix (e.g., Ollama uses /v1)
        base = self._base_url.rstrip("/")
        if base.endswith("/v1"):
            url = f"{base}/chat/completions"
        else:
            url = f"{base}/v1/chat/completions"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            try:
                response = await client.post(url, json=payload, headers=headers)
                response.raise_for_status()
                data = response.json()
            except httpx.ConnectError as e:
                raise TranslationError(
                    f"Could not connect to {self._base_url}. "
                    "Is the model server running?"
                ) from e
            except httpx.HTTPStatusError as e:
                error_text = (e.response.text or "")[:200]
                logger.error(
                    "OpenAI-compat API error: %s %s",
                    e.response.status_code,
                    error_text,
                )
                raise TranslationError(
                    f"API error {e.response.status_code}: {error_text}"
                ) from e

        # Extract translated text with safe error handling
        try:
            raw_text = data["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError, TypeError) as e:
            raise TranslationError(
                f"Unexpected response shape from {self._base_url}: {e}"
            ) from e

        # When PromptBuilder was used, the LLM response is JSON — extract
        # the translation value(s) from it
        translated_text = self._parse_response(raw_text, text, context)

        # Track usage
        usage = data.get("usage", {})
        tokens_in = usage.get("prompt_tokens", 0)
        tokens_out = usage.get("completion_tokens", 0)
        self._total_tokens_in += tokens_in
        self._total_tokens_out += tokens_out
        self._total_requests += 1

        billed_chars = (tokens_in + tokens_out) * 4

        return TranslationResult(
            text=translated_text,
            source_lang=source_lang,
            target_lang=target_lang,
            provider=self.name,
            confidence=0.8,
            billed_characters=billed_chars,
            quality_score=7.5,
            timestamp=datetime.now(),
            metadata={
                "model": self._model,
                "base_url": self._base_url,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                # Provenance flag (CORE-1804): "legacy_fallback" marks a
                # style-guide regression.
                "prompt_source": prompt_source,
            },
        )

    @staticmethod
    def _parse_response(
        raw_text: str,
        original_text: str,
        context: dict | None,
    ) -> str:
        """Extract the translation from an LLM response.

        Delegates to the shared :func:`response_parser.parse_llm_response`.
        """
        from .response_parser import parse_llm_response

        return parse_llm_response(raw_text, original_text, context)

    async def get_usage(self) -> UsageStats | None:
        if self._total_requests == 0:
            return None
        total_chars = (self._total_tokens_in + self._total_tokens_out) * 4
        return UsageStats(
            total_requests=self._total_requests,
            total_characters=total_chars,
            cost_estimate_usd=0.0,  # Local model: zero is a fact, not a guess
            characters_by_provider={self.name: total_chars},
            period_start=datetime.now(),
            period_end=datetime.now(),
        )
