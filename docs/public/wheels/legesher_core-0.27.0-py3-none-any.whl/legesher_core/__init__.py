"""Legesher Core - Translation engine for multilingual Python.

This package provides the core translation functionality for Legesher,
enabling developers to write Python code in their native language.

Public API:
    Translation Engine:
        - TokenTranslator: Token-based translation engine (simple, stable)
        - TreeSitterTranslator: Tree-sitter translation engine (4x faster, AST-based)
        - TokenMapper: Language map abstraction

    Language Abstraction Interface:
        - Translator: Protocol defining translator interface
        - create_translator: Factory function for creating translators
        - create_translator_from_language_pack: Convenience factory for language packs
        - get_default_backend: Query default backend from environment
        - get_supported_languages: List supported programming languages
        - TranslatorBackend: Type alias for backend selection

    Cultural Comments (MLCP Protocol):
        - CulturalComment: Immutable cultural comment metadata
        - CulturalCommentMetadata: Container for all cultural comments
        - CulturalCommentParser: Parser for extracting cultural comments
        - CulturalCommentProvider: High-level IDE integration API

    Git Integration & Metadata Tracking:
        - TranslationTracker: High-level API for tracking translations
        - MetadataManager: Low-level metadata persistence (internal)

    Round-Trip Verification:
        - first_divergence: Locate where two renderings stop matching
        - verify_round_trip: Round-trip source through a language and back,
          returning an earned, content-safe report
        - RoundTripReport: The result of one round trip - facts, not policy

    Exceptions:
        - TranslationError: Base exception class
        - InvalidCodeError: Raised for unparseable code
        - UnsupportedLanguageError: Raised for unsupported languages
        - EncodingError: Raised for non-UTF-8 files

Example:
    >>> from legesher_core import TokenTranslator
    >>> spanish_keywords = {"def": "definir", "return": "retornar"}
    >>> spanish_builtins = {"print": "imprimir"}
    >>> translator = TokenTranslator(spanish_keywords, spanish_builtins)
    >>> code = "def greet():\\n    print('Hello')"
    >>> spanish_code = translator.translate_code(code, "en", "es")

    >>> # Using factory function
    >>> from legesher_core import create_translator
    >>> translator = create_translator("python", spanish_keywords, spanish_builtins)
    >>> # Or use environment variable: export LEGESHER_USE_TREE_SITTER=true
    >>> translator = create_translator("python", spanish_keywords, spanish_builtins)

    >>> # With cultural comments
    >>> code_with_cultural = '''
    ... #@culture[es]: "hola" is informal, "buenos días" is formal
    ... def greet(): print("hola")
    ... '''
    >>> translated, metadata = translator.translate_code(
    ...     code_with_cultural, "en", "es", return_metadata=True
    ... )
    >>> metadata.has_comments()
    True

    >>> # Track translations
    >>> from pathlib import Path
    >>> from legesher_core import TranslationTracker, MetadataManager
    >>> manager = MetadataManager(Path(".legesher/metadata"))
    >>> tracker = TranslationTracker(manager)
    >>> tracker.track_clean(Path("src/main.py"), "es", "en")

The artifact normalization/hash contract lives in
``legesher_core.text_identity`` (imported by module path).
"""

from typing import TYPE_CHECKING

from .ai_context import (
    AIContextGenerator,
    generate_bilingual_examples,
    generate_builtin_table,
    generate_exception_table,
    generate_keyword_table,
)
from .cultural_comments import CulturalCommentParser
from .exceptions import (
    EncodingError,
    InvalidCodeError,
    TranslationError,
    UnsupportedLanguageError,
)
from .ide_support import CulturalCommentProvider
from .language_interface import (
    TranslatorBackend,
    TranslatorConfig,
    create_translator,
    create_translator_from_config,
    create_translator_from_language_pack,
    get_default_backend,
    get_supported_languages,
)
from .metadata import MetadataManager
from .round_trip import (
    RoundTripReport,
    first_divergence,
    verify_round_trip,
)
from .token_mapper import TokenMapper
from .transformer import TokenTranslator
from .translation_tracker import TranslationTracker
from .types import (
    CulturalComment,
    CulturalCommentMetadata,
    TextTranslationBackend,
    TranslationScope,
    Translator,
)

if TYPE_CHECKING:
    from .tree_sitter.llm_translator import LLMTranslator
    from .tree_sitter.translator import TreeSitterTranslator

__version__ = "0.27.0"

__all__ = [
    # Translation engine
    "TokenTranslator",
    "TreeSitterTranslator",
    "LLMTranslator",
    "TokenMapper",
    "TextTranslationBackend",
    "TranslationScope",
    # Language abstraction interface (CORE-415)
    "Translator",
    "TranslatorBackend",
    "TranslatorConfig",
    "create_translator",
    "create_translator_from_config",
    "create_translator_from_language_pack",
    "get_default_backend",
    "get_supported_languages",
    # AI context generation
    "AIContextGenerator",
    "generate_keyword_table",
    "generate_builtin_table",
    "generate_exception_table",
    "generate_bilingual_examples",
    # Cultural comments (MLCP)
    "CulturalComment",
    "CulturalCommentMetadata",
    "CulturalCommentParser",
    "CulturalCommentProvider",
    # Git integration & metadata
    "TranslationTracker",
    "MetadataManager",
    # Round-trip verification
    "RoundTripReport",
    "first_divergence",
    "verify_round_trip",
    # Exceptions
    "TranslationError",
    "InvalidCodeError",
    "UnsupportedLanguageError",
    "EncodingError",
]

#: Re-exports backed by the optional tree-sitter C extensions. Imported
#: lazily (PEP 562) so that ``import legesher_core`` — and the pure-stdlib
#: TokenTranslator path — works in environments without the C extensions
#: (minimal installs, browser Python runtimes). The extensions ship in the
#: optional ``treesitter`` extra: ``pip install legesher-core[treesitter]``.
_LAZY_TREE_SITTER_EXPORTS = frozenset({"LLMTranslator", "TreeSitterTranslator"})


def __getattr__(name: str) -> object:
    """Import tree-sitter-backed exports on first attribute access (PEP 562).

    Raises:
        ImportError: If the optional tree-sitter dependencies are not
            installed (the message names the ``treesitter`` extra).
        AttributeError: For attributes this package does not define.
    """
    if name in _LAZY_TREE_SITTER_EXPORTS:
        from . import tree_sitter as _tree_sitter_pkg

        return getattr(_tree_sitter_pkg, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(set(globals()) | _LAZY_TREE_SITTER_EXPORTS)
