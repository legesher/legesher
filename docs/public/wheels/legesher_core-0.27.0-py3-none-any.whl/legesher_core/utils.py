"""Utility functions for Legesher Core translation engine.

This module provides helper functions for encoding detection, validation,
and other common operations used throughout the translation pipeline.
"""

import ast
import re
from pathlib import Path

# Byte-order mark (U+FEFF). Legesher mandates UTF-8 *without* BOM.
_BOM = "﻿"

# PEP 263 encoding declaration, e.g. ``# -*- coding: latin-1 -*-`` on line 1/2.
_CODING_RE = re.compile(r"coding[:=]\s*([-\w.]+)")


def validate_utf8_encoding(file_path: Path) -> str:
    """Validate that a Python source file is UTF-8 encoded.

    Note: This function validates UTF-8 encoding rather than detecting
    arbitrary encodings, as Legesher mandates UTF-8 for all files to
    properly handle multilingual code, especially RTL languages like Arabic.

    Args:
        file_path: Path to the Python source file

    Returns:
        Encoding string ('utf-8') if validation succeeds

    Raises:
        EncodingError: If file is not UTF-8 encoded

    Example:
        >>> encoding = validate_utf8_encoding(Path("my_code.py"))
        >>> assert encoding == "utf-8"
    """
    from .exceptions import EncodingError

    try:
        # Try to read file as UTF-8
        with open(file_path, encoding="utf-8") as f:
            f.read()
        return "utf-8"
    except UnicodeDecodeError as e:
        raise EncodingError(
            f"File '{file_path}' must be UTF-8 encoded. Detected encoding error: {e}"
        ) from e


# Backwards compatibility alias
detect_encoding = validate_utf8_encoding


def validate_python_code(code: str) -> bool:
    """Check if code is syntactically valid Python.

    Uses Python's AST parser to validate syntax without executing code.
    Note: This validates complete syntax, but incomplete code (like a user
    typing in real-time) may fail validation even though tokenization can
    handle it gracefully.

    Args:
        code: Python source code string

    Returns:
        True if code is syntactically valid, False otherwise

    Example:
        >>> validate_python_code("def foo(): return 42")
        True
        >>> validate_python_code("def foo)(:")
        False
    """
    try:
        ast.parse(code)
        return True
    except SyntaxError:
        return False


def normalize_newlines(code: str) -> str:
    """Normalize line endings to Unix-style (\\n).

    Converts Windows (\\r\\n) and old Mac (\\r) line endings to Unix (\\n)
    for consistent processing across platforms.

    Args:
        code: Source code with potentially mixed line endings

    Returns:
        Source code with normalized \\n line endings

    Example:
        >>> normalize_newlines("line1\\r\\nline2\\rline3\\n")
        'line1\\nline2\\nline3\\n'
    """
    # Replace Windows CRLF with LF
    code = code.replace("\r\n", "\n")
    # Replace old Mac CR with LF
    code = code.replace("\r", "\n")
    return code


def is_rtl_language(lang_code: str) -> bool:
    """Check if a language is right-to-left (RTL).

    RTL languages require special handling for Unicode preservation,
    though the actual visual rendering is the IDE's responsibility.

    Args:
        lang_code: ISO 639-1 or custom language code (e.g., "ar", "he")

    Returns:
        True if language is RTL, False otherwise

    Example:
        >>> is_rtl_language("ar")  # Arabic
        True
        >>> is_rtl_language("he")  # Hebrew
        True
        >>> is_rtl_language("en")  # English
        False
        >>> is_rtl_language("es")  # Spanish
        False
    """
    # Common RTL language codes
    RTL_LANGUAGES = {
        "ar",  # Arabic
        "he",  # Hebrew
        "ur",  # Urdu
        "fa",  # Persian/Farsi
        "yi",  # Yiddish
        "ji",  # Yiddish (alternate code)
    }

    return lang_code.lower() in RTL_LANGUAGES


def merge_exception_translations(
    builtin_map: dict[str, str],
    exceptions: dict[str, str],
) -> dict[str, str]:
    """Merge exception translations into a builtin map with PascalCase keys.

    Language packs store exception keys lowercase (``valueerror``) but Python
    uses PascalCase (``ValueError``).  This function remaps using Python's
    actual builtin exception names.

    Identity VALUES are canonicalized the same way: a pack that ships
    ``typeerror: typeerror`` (the en pack's identity baseline, CORE-1570)
    would otherwise map ``TypeError`` to ``typeerror`` and the translator
    would emit a broken except clause. A value equal to its lowercase key is
    the pack saying "this name translates to itself", so the canonical
    PascalCase name is the only correct rendering.

    Args:
        builtin_map: Existing builtin translations (will not be mutated).
        exceptions: Exception translations from the language pack (lowercase keys).

    Returns:
        New dict with builtins + exceptions merged.
    """
    import builtins as _builtins

    merged = dict(builtin_map)

    # Build lowercase → PascalCase lookup from Python's actual exception names
    pascal_map = {}
    for name in dir(_builtins):
        obj = getattr(_builtins, name, None)
        if isinstance(obj, type) and issubclass(obj, BaseException):
            pascal_map[name.lower()] = name

    for lower_name, translation in exceptions.items():
        canonical = pascal_map.get(lower_name, lower_name)
        if translation == lower_name:
            # Identity mapping: render the canonical name, never the
            # lowercase spelling the pack stored the key under.
            translation = canonical
        merged[canonical] = translation

    return merged


def continues_identifier(char: str) -> bool:
    """Whether ``char`` can sit inside an identifier, by Python's own rules.

    Not ``\\w``: combining marks (a Devanagari vowel sign, an Arabic
    haraka, a Thai tone mark), connector punctuation and the other
    ``Other_ID_Continue`` characters continue a word too. The pure-Python
    tokenizer of CPython 3.10 and 3.11 reads names as ``\\w+`` and splits a
    word at those characters, so anything that decides where a word ends
    from tokens on those versions asks this instead.
    """
    return ("a" + char).isidentifier()


def strip_bom(code: str) -> str:
    """Strip a single leading byte-order mark (U+FEFF) from source text.

    A leading BOM desyncs byte/char offsets and confuses PEP 263 detection, so
    the translate path removes it. Interior U+FEFF is left untouched.
    """
    if code.startswith(_BOM):
        return code[len(_BOM) :]
    return code


def check_coding_declaration(code: str) -> str | None:
    """Return a non-UTF-8 PEP 263 coding declaration if present, else None.

    Python only honours a coding declaration on the first or second physical
    line. Legesher mandates UTF-8, so anything other than a UTF-8 alias is a
    problem the caller should warn about or reject.
    """
    lines = code.split("\n", 2)[:2]
    for line in lines:
        match = _CODING_RE.search(line)
        if match:
            enc = match.group(1).lower().replace("_", "-")
            if enc not in ("utf-8", "utf8"):
                return match.group(1)
            return None
    return None
