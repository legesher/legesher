"""Full LLM-powered code translator for Python.

Composes TreeSitterTranslator (keywords/builtins) with a pluggable
TextTranslationBackend (identifiers, comments, docstrings, strings)
to translate entire Python files between natural languages.

This is the main entry point for Condition 5 (full translation) and
implements the Translator protocol for polymorphic usage.
"""

import hashlib
import logging
import sys
from pathlib import Path
from typing import Any

from ..exceptions import InvalidCodeError
from ..token_mapper import TokenMapper
from ..types import (
    CulturalCommentMetadata,
    TextTranslationBackend,
    TranslatableElement,
    TranslationScope,
)
from .extractor import TranslatableExtractor
from .identifier_map import IdentifierMap
from .identifier_validator import IdentifierValidator
from .parser import PythonParser
from .translation_logger import TranslationLogger
from .translator import TreeSitterTranslator

logger = logging.getLogger(__name__)


class LLMTranslator:
    """Full-code translator using LLM backends for identifiers, comments, strings.

    Composes TreeSitterTranslator (keywords/builtins via language packs) with a
    TextTranslationBackend (LLM for everything else). Maintains identifier
    consistency via IdentifierMap and validates output for valid Python syntax.

    Implements the Translator protocol for polymorphic usage with
    create_translator() factory.

    Example:
        >>> from legesher_core.types import TextTranslationBackend
        >>> class MockBackend:
        ...     def translate_text(self, text, source_lang, target_lang, context=None):
        ...         return f"translated_{text}"
        ...     def translate_batch(self, items, source_lang, target_lang):
        ...         return [f"translated_{i['text']}" for i in items]
        >>> translator = LLMTranslator(
        ...     keyword_map={"def": "definir"},
        ...     builtin_map={"print": "imprimir"},
        ...     backend=MockBackend(),
        ... )
        >>> code = 'def greet():\\n    print("Hello")'
        >>> translated = translator.translate_code(code, "en", "es")
    """

    def __init__(
        self,
        keyword_map: dict[str, str],
        builtin_map: dict[str, str],
        backend: TextTranslationBackend,
        python_version: str = "3.13",
        implicit_param_map: dict[str, str] | None = None,
        identifier_map: IdentifierMap | None = None,
        scope: TranslationScope | None = None,
        translation_logger: TranslationLogger | None = None,
        forbidden_identifier_values: list[str] | None = None,
    ) -> None:
        """Initialize the LLM translator.

        Args:
            keyword_map: Keyword translation mappings from language pack
            builtin_map: Builtin translation mappings from language pack
            backend: LLM backend for translating identifiers/comments/strings
            python_version: Python version for version-aware packs
            implicit_param_map: Optional mapping of Python conventions like
                ``self`` and ``cls`` to target language (CORE-710). Threaded
                through the inner ``TreeSitterTranslator`` and ``TokenMapper``
                so the dispatch order substitutes self/cls deterministically
                even though the extractor skips them from LLM input.
            identifier_map: Optional pre-populated identifier map for consistency
            scope: Optional scope config to toggle what gets translated
            translation_logger: Optional logger for training data collection
            forbidden_identifier_values: Optional flat list of translation
                values the LLM must NOT propose as identifier translations.
                Typically the union of pack ``keywords``, ``builtins``,
                ``exceptions``, and ``implicit_params`` values. Threaded
                into every identifier batch's ``context.forbidden_values``
                so the backend can pass them to ``PromptBuilder``. Text
                items (comments/docstrings/strings) do not receive this
                list -- prose translations don't have collision risk.
                CORE-710 / CORE-950.
        """
        self.keyword_translator = TreeSitterTranslator(
            keyword_map=keyword_map,
            builtin_map=builtin_map,
            python_version=python_version,
            implicit_param_map=implicit_param_map,
        )
        self.backend = backend
        self.mapper = TokenMapper(keyword_map, builtin_map, implicit_param_map)
        # Use ``is None`` rather than ``or`` because IdentifierMap defines
        # __len__, so an empty (but caller-provided, possibly pack-aware)
        # map evaluates falsy and would silently get replaced by a fresh
        # one with no pack attached -- regression for CORE-950 collision
        # detection.
        self.identifier_map = (
            identifier_map if identifier_map is not None else IdentifierMap()
        )
        self.scope = scope or TranslationScope()
        self.validator = IdentifierValidator()
        self.extractor = TranslatableExtractor(self.mapper)
        self.parser = PythonParser()
        self.python_version = python_version
        self.translation_logger = translation_logger
        self.forbidden_identifier_values = forbidden_identifier_values

    def translate_code(
        self,
        source_code: str,
        source_lang: str = "en",
        target_lang: str = "es",
        return_metadata: bool = False,
    ) -> str | tuple[str, CulturalCommentMetadata]:
        """Translate Python source code with full LLM translation.

        Pipeline:
        1. Parse with tree-sitter
        2. Extract all translatable elements
        3. Translate keywords/builtins via language packs
        4. Translate identifiers via LLM (with dedup + validation)
        5. Translate comments/docstrings/strings via LLM
        6. Apply all replacements
        7. Verify output parses

        Args:
            source_code: Python source code to translate
            source_lang: Source language code (default: "en")
            target_lang: Target language code (default: "es")
            return_metadata: If True, return tuple with cultural comment metadata

        Returns:
            Translated Python source code, or tuple if return_metadata=True
        """
        if not source_code or not source_code.strip():
            if return_metadata:
                return source_code, CulturalCommentMetadata()
            return source_code

        try:
            # Step 1: Parse and extract
            elements = self.extractor.extract(source_code)

            # Step 2: Get keyword/builtin replacements from existing translator
            tree = self.parser.parse(source_code)
            keyword_replacements: list[tuple[int, int, str]] = []
            self.keyword_translator._find_translations(
                tree.root_node, keyword_replacements
            )

            # Step 3: Translate identifiers via LLM
            identifier_replacements = self._translate_identifiers(
                elements, source_lang, target_lang
            )

            # Step 4: Translate comments, docstrings, strings via LLM
            text_replacements = self._translate_text_elements(
                elements, source_lang, target_lang
            )

            # Step 5: Merge all replacements (avoid overlaps)
            all_replacements = self._merge_replacements(
                keyword_replacements, identifier_replacements, text_replacements
            )

            # Step 6: Apply replacements
            byte_to_char = TreeSitterTranslator._build_byte_to_char_map(source_code)
            translated = self._apply_replacements(
                source_code, all_replacements, byte_to_char
            )

            # Step 7: Verify output parses
            self._verify_output(translated, source_code, len(keyword_replacements))

            if return_metadata:
                return translated, CulturalCommentMetadata()
            return translated

        except Exception as e:
            logger.error("LLM translation failed: %s", e)
            raise InvalidCodeError("Failed to translate code") from e

    def _translate_identifiers(
        self,
        elements: list[TranslatableElement],
        source_lang: str,
        target_lang: str,
    ) -> list[tuple[int, int, str]]:
        """Translate identifiers via LLM with dedup and validation."""
        if not self.scope.translate_identifiers:
            return []

        # Collect unique identifiers
        identifier_elements = [e for e in elements if e.kind == "identifier"]
        # Preserve first-seen order for deterministic batching
        unique_ids = list(dict.fromkeys(e.text for e in identifier_elements))

        # Filter out already-translated identifiers
        untranslated = self.identifier_map.get_untranslated(unique_ids, target_lang)

        if untranslated:
            # Build batch with context
            glossary = self.identifier_map.get_glossary(target_lang)
            items = []
            for text in untranslated:
                # Find the first element with this text for context
                elem = next((e for e in identifier_elements if e.text == text), None)
                context: dict[str, Any] = {}
                if elem:
                    context = {**elem.context, "glossary": glossary}
                    context["role"] = elem.role
                if self.forbidden_identifier_values:
                    # CORE-950: hand the backend the reserved-values list
                    # so it can pass forbidden_values=... to PromptBuilder.
                    context["forbidden_values"] = self.forbidden_identifier_values
                items.append({"text": text, "context": context})

            # Batch translate
            translations = self.backend.translate_batch(items, source_lang, target_lang)

            # Validate and store
            for text, translation in zip(untranslated, translations):
                valid = self.validator.is_valid(translation)
                if not valid:
                    raw_attempt = translation  # Preserve for logging
                    # Log failure for training data
                    if self.translation_logger:
                        self.translation_logger.log_validation_failure(
                            identifier=text,
                            first_attempt=raw_attempt,
                            failure_reason="invalid Python identifier",
                        )
                    # Try sanitizing
                    translation = self.validator.sanitize(translation)
                    if self.translation_logger:
                        self.translation_logger.log_validation_failure(
                            identifier=text,
                            first_attempt=raw_attempt,
                            failure_reason="sanitized",
                            retry_result=translation,
                            retry_valid=self.validator.is_valid(translation),
                        )

                # CORE-950 layer 2: when the IdentifierMap is pack-aware,
                # ``.add()`` raises ValueError on collisions with reserved
                # pack values (keywords / builtins / exceptions /
                # implicit_params). Wrap in try/except and apply a numeric
                # suffix as a deterministic fallback so a single collision
                # doesn't crash the whole batch. Layer 1 (forbidden_values
                # in the prompt) makes this rare; the suffix is the
                # safety net.
                try:
                    self.identifier_map.add(text, target_lang, translation)
                except ValueError:
                    translation = self._suffix_until_clean(
                        text, target_lang, translation
                    )

                # Log for training data
                if self.translation_logger:
                    elem = next(
                        (e for e in identifier_elements if e.text == text), None
                    )
                    self.translation_logger.log_identifier_pair(
                        source=text,
                        target=translation,
                        target_lang=target_lang,
                        role=elem.role if elem else "other",
                        naming_convention=(
                            elem.context.get("naming_convention", "unknown")
                            if elem
                            else "unknown"
                        ),
                        context=elem.context if elem else None,
                    )

        # Build replacement list
        replacements: list[tuple[int, int, str]] = []
        for elem in identifier_elements:
            translation = self.identifier_map.get(elem.text, target_lang)
            if translation and translation != elem.text:
                replacements.append((elem.start_byte, elem.end_byte, translation))

        return replacements

    def _translate_text_elements(
        self,
        elements: list[TranslatableElement],
        source_lang: str,
        target_lang: str,
    ) -> list[tuple[int, int, str]]:
        """Translate comments, docstrings, and strings via LLM."""
        replacements: list[tuple[int, int, str]] = []

        # Collect elements to translate based on scope
        to_translate = []
        for elem in elements:
            if elem.kind == "identifier":
                continue
            if elem.kind == "comment" and not self.scope.translate_comments:
                continue
            if elem.kind == "docstring" and not self.scope.translate_docstrings:
                continue
            if elem.kind == "string" and not self.scope.translate_strings:
                continue
            to_translate.append(elem)

        if not to_translate:
            return []

        # Batch translate — include identifier glossary so text elements
        # (comments, docstrings, strings) use the same terms as translated identifiers
        glossary = self.identifier_map.get_glossary(target_lang)
        items = [
            {
                "text": elem.text,
                "context": {**elem.context, "kind": elem.kind, "glossary": glossary},
            }
            for elem in to_translate
        ]
        translations = self.backend.translate_batch(items, source_lang, target_lang)

        for elem, translation in zip(to_translate, translations):
            if translation and translation != elem.text:
                if elem.kind == "comment":
                    # Reconstruct comment with # prefix from extractor context
                    # elem.text is content only (no #), hash_prefix is in context
                    hash_prefix = elem.context.get("hash_prefix", "# ")
                    # Handle multi-line LLM responses: prefix each line with #
                    if "\n" in translation:
                        lines = translation.split("\n")
                        translated_comment = "\n".join(
                            f"{hash_prefix}{line}" for line in lines
                        )
                    else:
                        translated_comment = f"{hash_prefix}{translation}"
                    replacements.append(
                        (elem.start_byte, elem.end_byte, translated_comment)
                    )
                elif elem.kind in ("docstring", "string"):
                    is_fstring_content = elem.context.get("is_fstring_content", False)
                    if is_fstring_content:
                        # F-string string_content: insert raw text, no quotes
                        safe_translation = translation
                        # Escape braces to avoid creating new interpolations
                        safe_translation = safe_translation.replace("{", "{{").replace(
                            "}", "}}"
                        )
                        # For non-triple-quoted f-strings, escape newlines
                        is_triple = elem.context.get("is_triple_quoted", False)
                        if not is_triple and "\n" in safe_translation:
                            safe_translation = safe_translation.replace("\n", "\\n")
                        reconstructed = safe_translation
                    else:
                        # Full string/docstring: reconstruct with quotes
                        prefix_str = elem.prefix or ""
                        quote = elem.quote_style or '"""'
                        safe_translation = translation.replace(
                            quote, "\\" + quote[0] + quote[1:]
                        )
                        # For non-triple-quoted strings, escape newlines
                        if quote in ("'", '"') and "\n" in safe_translation:
                            safe_translation = safe_translation.replace("\n", "\\n")
                        reconstructed = f"{prefix_str}{quote}{safe_translation}{quote}"
                    replacements.append((elem.start_byte, elem.end_byte, reconstructed))

                # Log for training data
                if self.translation_logger:
                    self.translation_logger.log_text_pair(
                        source=elem.text,
                        target=translation,
                        target_lang=target_lang,
                        kind=elem.kind,
                        context=elem.context,
                    )

        return replacements

    def _suffix_until_clean(
        self, text: str, target_lang: str, base: str, max_suffix: int = 9
    ) -> str:
        """Append a numeric suffix to ``base`` until ``IdentifierMap.add``
        accepts it without a pack collision.

        The pack-aware ``IdentifierMap`` raises ``ValueError`` when a
        translation matches a reserved pack value. Reserved values are
        translations of keywords / builtins / exceptions / implicit_params
        from the language pack -- they don't typically end in ``_2`` or
        similar, so a numeric suffix nearly always resolves the
        collision in one step. The loop is bounded; a deterministic
        hash-based suffix is the last-resort fallback.

        Returns the suffixed translation that was successfully added.

        Args:
            text: Source identifier (used for the hash fallback).
            target_lang: Target language code.
            base: The collision-causing translation candidate.
            max_suffix: Max numeric suffix to try before falling back to
                a hash. Default 9 keeps the loop tight; reserved-value
                collisions on suffixed forms are essentially impossible
                in practice.

        Returns:
            The accepted translation value (already stored in the map).
        """
        for i in range(2, max_suffix + 1):
            candidate = f"{base}_{i}"
            try:
                self.identifier_map.add(text, target_lang, candidate)
                logger.warning(
                    "Pack collision on %r -> %r; recovered with suffix -> %r",
                    text,
                    base,
                    candidate,
                )
                return candidate
            except ValueError:
                continue

        # Exhausted the small suffix range -- fall back to a stable
        # SHA-256-derived suffix. Python's built-in ``hash()`` is
        # process-randomized (PYTHONHASHSEED), which would break the
        # round-trip property of the IdentifierMap across runs;
        # SHA-256 is deterministic so the same source identifier always
        # gets the same suffix. We extend the slice on the (1-in-10^19)
        # case where the first 16 hex chars happen to also collide,
        # walking through the full 64-char digest before giving up.
        # Copilot review on PR #237 flagged the original `hash()` use.
        stable = hashlib.sha256(text.encode("utf-8")).hexdigest()
        for slice_end in (16, 24, 32, 48, 64):
            candidate = f"{base}_{stable[:slice_end]}"
            try:
                self.identifier_map.add(text, target_lang, candidate)
                logger.warning(
                    "Pack collision on %r -> %r exhausted suffix range; "
                    "fell back to hash-suffixed %r",
                    text,
                    base,
                    candidate,
                )
                return candidate
            except ValueError:
                continue

        raise ValueError(
            f"Could not recover from pack collision: {text!r} -> {base!r}. "
            f"Even the SHA-256 hash-suffixed candidates collided. The pack "
            f"contains a pathological number of reserved values."
        )

    @staticmethod
    def _merge_replacements(
        *replacement_lists: list[tuple[int, int, str]],
    ) -> list[tuple[int, int, str]]:
        """Merge replacement lists, resolving overlaps by priority.

        Earlier lists have higher priority (keywords > identifiers > text).
        Overlapping replacements from lower-priority lists are dropped.
        """
        # Collect all with priority
        all_replacements: list[tuple[int, int, str, int]] = []
        for priority, rlist in enumerate(replacement_lists):
            for start, end, text in rlist:
                all_replacements.append((start, end, text, priority))

        # Sort by start position, then by priority (lower = higher priority)
        all_replacements.sort(key=lambda r: (r[0], r[3]))

        # Remove overlaps — keep higher priority
        merged: list[tuple[int, int, str]] = []
        last_end = -1
        for start, end, text, _priority in all_replacements:
            if start >= last_end:
                merged.append((start, end, text))
                last_end = end

        return merged

    @staticmethod
    def _apply_replacements(
        source_code: str,
        replacements: list[tuple[int, int, str]],
        byte_to_char: dict[int, int],
    ) -> str:
        """Apply replacements to source code in reverse byte order."""
        # Sort in reverse order to apply from end to start
        sorted_replacements = sorted(replacements, key=lambda r: r[0], reverse=True)

        result = source_code
        for start_byte, end_byte, replacement_text in sorted_replacements:
            start_char = byte_to_char.get(start_byte, start_byte)
            end_char = byte_to_char.get(end_byte, end_byte)
            result = result[:start_char] + replacement_text + result[end_char:]

        return result

    def _verify_output(
        self, translated: str, original: str, keyword_replacement_count: int = 0
    ) -> None:
        """Verify that translated output doesn't introduce structural damage.

        Note: Tree-sitter uses the English Python grammar, so translated
        keywords (e.g., 'definir' instead of 'def') always produce parse
        "errors" — these are expected and harmless. We log a warning if the
        translated output has significantly MORE errors than expected from
        keyword translation, which may indicate broken reconstruction.

        Args:
            translated: The translated source code
            original: The original source code
            keyword_replacement_count: Number of keyword replacements made
        """
        try:
            original_tree = self.parser.parse(original)
            original_errors = self._count_errors(original_tree.root_node)

            translated_tree = self.parser.parse(translated)
            translated_errors = self._count_errors(translated_tree.root_node)

            new_errors = translated_errors - original_errors
            # Each keyword replacement can cause ~1 parse error in the English grammar.
            # Allow that plus a small tolerance for identifier/string changes.
            allowed = keyword_replacement_count + 5
            if new_errors > allowed:
                logger.warning(
                    "Translation may have structural issues: %d new parse errors "
                    "(expected up to %d from %d keyword replacements, got %d total)",
                    new_errors,
                    allowed,
                    keyword_replacement_count,
                    translated_errors,
                )
        except Exception as e:
            logger.warning("Could not verify translated output: %s", e)

    def _count_errors(self, node) -> int:
        """Count ERROR nodes in a tree-sitter parse tree."""
        count = 1 if node.type == "ERROR" else 0
        for child in node.children:
            count += self._count_errors(child)
        return count

    def translate_file(self, file_path: Path, target_lang: str) -> str:
        """Translate a Python file to the target language.

        Args:
            file_path: Path to Python file
            target_lang: Target language code

        Returns:
            Translated Python source code
        """
        source_code = file_path.read_text(encoding="utf-8")
        result = self.translate_code(source_code, "en", target_lang)
        if isinstance(result, tuple):
            return result[0]
        return result

    def reverse(self) -> "LLMTranslator":
        """Create a reverse translator.

        Note: LLM translation is non-deterministic, so reverse translation
        uses the IdentifierMap for consistent round-trips. Comments and
        strings will be re-translated by the LLM.
        """
        reversed_keyword = {v: k for k, v in self.mapper.keyword_map.items()}
        reversed_builtin = {v: k for k, v in self.mapper.builtin_map.items()}
        # CORE-710: also reverse the implicit_param_map so round-trip restores self/cls.
        reversed_reserved = {v: k for k, v in self.mapper.implicit_param_map.items()}
        return LLMTranslator(
            keyword_map=reversed_keyword,
            builtin_map=reversed_builtin,
            backend=self.backend,
            python_version=self.python_version,
            implicit_param_map=reversed_reserved,
            identifier_map=self.identifier_map,
            scope=self.scope,
        )

    @classmethod
    def from_language_pack(
        cls,
        language: str,
        python_version: str | None = None,
        backend: TextTranslationBackend | None = None,
    ) -> "LLMTranslator":
        """Create LLM translator from a language pack.

        Args:
            language: Natural language code (e.g., "es", "zh", "ur")
            python_version: Python version (auto-detects if None)
            backend: LLM backend (required for LLM translation)

        Returns:
            LLMTranslator instance

        Raises:
            ValueError: If no backend is provided
        """
        if backend is None:
            raise ValueError(
                "LLMTranslator requires a TextTranslationBackend. "
                "Use TreeSitterTranslator.from_language_pack() for "
                "keyword-only translation."
            )

        from legesher_i18n import LanguagePackLoader

        if python_version is None:
            version_info = sys.version_info
            python_version = f"{version_info.major}.{version_info.minor}"

        loader = LanguagePackLoader()
        pack = loader.load(language, target="python", version=python_version)

        # CORE-710: pull implicit_params from the pack if present (defaults to {})
        implicit_param_map = getattr(pack, "implicit_params", {}) or {}

        # CORE-950 two-layer collision defense (CORE-710 deferred this).
        #
        # Layer 1 (prompt): aggregate every reserved value the LLM could
        # collide with -- keywords, builtins, exceptions, implicit_params --
        # and pass them to the backend via per-item context.forbidden_values
        # so PromptBuilder lists them in the identifier prompt. Makes
        # collision proposals rare.
        #
        # Layer 2 (translator): construct a pack-aware IdentifierMap so
        # ``.add()`` raises ValueError on any collision that slips
        # through. _translate_identifiers wraps in try/except and applies
        # numeric-suffix recovery so a single collision can't crash the
        # batch.
        forbidden_identifier_values: list[str] = []
        for mapping in (
            pack.keywords,
            pack.builtins,
            getattr(pack, "exceptions", {}) or {},
            implicit_param_map,
        ):
            forbidden_identifier_values.extend(mapping.values())

        identifier_map = IdentifierMap(pack=pack)

        return cls(
            keyword_map=pack.keywords,
            builtin_map=pack.builtins,
            backend=backend,
            python_version=python_version,
            implicit_param_map=implicit_param_map,
            forbidden_identifier_values=forbidden_identifier_values or None,
            identifier_map=identifier_map,
        )

    @classmethod
    def list_available_languages(cls) -> list[tuple[str, str]]:
        """List all available language packs."""
        from legesher_i18n import LanguagePackLoader

        loader = LanguagePackLoader()
        return loader.list_available_languages()

    def get_pack_info(self) -> dict[str, str | int]:
        """Get information about the loaded language pack."""
        return {
            "language": "unknown",
            "python_version": self.python_version,
            "keyword_count": len(self.mapper.keyword_map),
            "builtin_count": len(self.mapper.builtin_map),
            "backend": "llm",
        }
